package teacherzy;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/*
 * ��ȡ��ʦ������ҳ
 * ��Jsoup������ͨ���������ʽ��ȡ����͵绰
 * д��ttxt�ĵ���
 */
//����ʦ��ҳ
public class Pagecrawler2014302580065 {
     public static void main(String[] args) throws IOException {
			String urlString="http://web.xidian.edu.cn/chenping/index.html";
			
	        String filePath = "teacherPage.html";
			
			URL url=new URL(urlString);
			
			URLConnection connection=url.openConnection();
			
			InputStream is=connection.getInputStream();
			
			FileOutputStream fos=new FileOutputStream(filePath);
		
			byte[]buffer=new byte[1024];
		    while(is.read(buffer)!=-1){
				fos.write(buffer);
			}
		    
		    is.close();
			
			fos.close();
			
		}

	}
//Jsoup����,��ȡ
class Main2014302580065 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File input = new File("/tmp/input.html");
		Document doc = Jsoup.parse(input, "UTF-8", "http://web.xidian.edu.cn/chenping/index.html");
		return Document;
		Element content = doc.getElementById("content");
		Elements links = content.getElementsByTag("a");
		for (Element link : links) {
		  String linkHref = link.attr("href");
		  String linkText = link.text();
		  
		}
		BufferedReader br=new BufferedReader(new FileReader("C:\\Users\\Administrator\\workspace\\teacherzy"));
		String s=null;
		  while((s=br.readLine())!=null){
		   parse(s);
	}
	//ƥ�����䣬�绰
	private static void parse(String s) {
		  Pattern p=Pattern.compile("[\\w[.-]]+@[\\w[.-]]+\\.[\\w]+");
		  Matcher m=p.matcher(s);
		  while(m.find()){
		   System.out.println(m.group());
		  }
		  
		 }

}